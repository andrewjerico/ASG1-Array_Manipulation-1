#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#include "object.h"
#include "other.h"
#include "string.h"

#include "menu1.h"
#include "menu2.h"
#include "menu3.h"
#include "menu4.h"
#include "mainMenu.h"


int main() 
{
    mainMenu();
    return 0;
}
