struct Dessert {
    char name[255];
    int price;
    char topping[25];
    double calories;
    char flavour[25];
    char size;
    int time;
};